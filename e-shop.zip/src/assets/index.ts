import backIcon from "./backIcon.png";

export { backIcon };
